const express = require('express');
const router = express.Router();
const db = require('../config/database');
const { authenticateToken, isAdmin } = require('../middleware/auth');

// Get all kapal
router.get('/kapal/m', authenticateToken, async (req, res) => {
  try {
    const [rows] = await db.execute('SELECT * FROM kapal');
    res.json(rows);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get single kapal
router.get('/kapal/minpro/:id', authenticateToken, async (req, res) => {
  try {
    const [rows] = await db.execute('SELECT * FROM kapal WHERE id_kapal = ?', [req.params.id]);
    if (rows.length === 0) {
      return res.status(404).json({ error: 'Kapal not found' });
    }
    res.json(rows[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Create kapal
router.post('/kapal/minpro/', authenticateToken, isAdmin, async (req, res) => {
  try {
    const { nama_kapal, jenis_kapal, kapasitas_muatan } = req.body;
    
    // Validation
    if (!nama_kapal) {
      return res.status(400).json({ error: 'Nama kapal is required' });
    }
    if (kapasitas_muatan <= 0) {
      return res.status(400).json({ error: 'Kapasitas muatan must be positive' });
    }

    const [result] = await db.execute(
      'INSERT INTO kapal (nama_kapal, jenis_kapal, kapasitas_muatan) VALUES (?, ?, ?)',
      [nama_kapal, jenis_kapal, kapasitas_muatan]
    );

    const io = req.app.get('io');
    io.emit('data_changed', {
      event: 'created',
      message: 'New ship added',
      data: { id_kapal: result.insertId, nama_kapal, jenis_kapal, kapasitas_muatan }
    });

    res.status(201).json({ 
      message: 'Kapal created successfully',
      id: result.insertId 
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Update kapal
router.put('/kapal/minpro/:id', authenticateToken, isAdmin, async (req, res) => {
  try {
    const { nama_kapal, jenis_kapal, kapasitas_muatan } = req.body;
    
    // Validation
    if (!nama_kapal) {
      return res.status(400).json({ error: 'Nama kapal is required' });
    }
    if (kapasitas_muatan <= 0) {
      return res.status(400).json({ error: 'Kapasitas muatan must be positive' });
    }

    const [result] = await db.execute(
      'UPDATE kapal SET nama_kapal = ?, jenis_kapal = ?, kapasitas_muatan = ? WHERE id_kapal = ?',
      [nama_kapal, jenis_kapal, kapasitas_muatan, req.params.id]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Kapal not found' });
    }

    const io = req.app.get('io');
    io.emit('data_changed', {
      event: 'updated',
      message: 'Ship updated',
      data: { id_kapal: req.params.id, nama_kapal, jenis_kapal, kapasitas_muatan }
    });

    res.json({ message: 'Kapal updated successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Delete kapal
router.delete('/kapal/minpro/:id', authenticateToken, isAdmin, async (req, res) => {
  try {
    const [result] = await db.execute('DELETE FROM kapal WHERE id_kapal = ?', [req.params.id]);
    
    if (result.affectedRows === 0) {
      return res.status(404).json({ error: 'Kapal not found' });
    }

    const io = req.app.get('io');
    io.emit('data_changed', {
      event: 'deleted',
      message: 'Ship deleted',
      data: { id_kapal: req.params.id }
    });

    res.json({ message: 'Kapal deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;