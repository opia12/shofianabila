const mysql = require('mysql2');
require('dotenv').config();

const pool = mysql.createPool({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.nabil,
  database: process.env.kapal_db,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

// konfigurasi koneksi mysql
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'kapal_db'
});

// koneksi ke databse
db.connect((err) => {
    if (err) {
        console.error('error koneksi mysql:', err);
    } else {
        console.log('koneksi mysql berhasil');
    }
});

module.exports = db;

module.exports = pool.promise();